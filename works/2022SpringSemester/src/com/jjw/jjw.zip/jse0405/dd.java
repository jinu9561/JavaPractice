package com.jjw.jse0405;

public class dd {

	public static void main(String[] args) {
		int arr[] = new int[0];
		arr[0] = 1;
		System.out.println(arr[0]);
	}
}
